import React from 'react';
import DashboardLayout from './components/DashboardLayout';

function App() {
  return (
    <div className="App">
      <DashboardLayout />
    </div>
  );
}

export default App;
