// Código proporcionado, ajustado a un entorno moderno
import React, { useState } from 'react';
import {
  Bell,
  Calendar,
  ChevronDown,
  Clock,
  FileText,
  Filter,
  Home,
  MessageSquare,
  Plus,
  Search,
  Settings,
  Users,
} from 'lucide-react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from './ui/Card';

const DashboardLayout = () => {
  const [activeSection, setActiveSection] = useState('dashboard');

  const metrics = [
    { title: 'OPD Today', value: '250', icon: <Users className="w-4 h-4" /> },
    { title: 'Relieved Today', value: '89', icon: <Users className="w-4 h-4" /> },
    { title: 'In Patient Today', value: '300', icon: <Users className="w-4 h-4" /> },
    { title: 'Ventilator', value: '52', icon: <Users className="w-4 h-4" /> },
  ];

  const recentPatients = [
    { id: 'RCC22279', name: 'Imran', date: '12-11-2000', status: 'ICU', doctor: 'Dr. Vandana Sharma' },
    { id: 'RCC22274', name: 'Janvik', date: '11-2-2024', status: 'Visited', doctor: 'Dr. Vandana Sharma' },
    { id: 'ACC22276', name: 'Kasim', date: '12-2-2024', status: 'Revisit', doctor: 'Dr. Vandana Sharma' },
  ];

  return (
    <div className="flex min-h-screen bg-gray-50">
      <div className="w-64 bg-white border-r p-4">
        <div className="flex items-center gap-2 mb-8">
          <div className="text-2xl font-bold text-blue-600">MediPuls</div>
        </div>

        <nav className="space-y-2">
          {[
            { icon: <Home className="w-4 h-4" />, label: 'Dashboard' },
            { icon: <Calendar className="w-4 h-4" />, label: 'Appointments' },
            { icon: <Users className="w-4 h-4" />, label: 'Patients' },
            { icon: <MessageSquare className="w-4 h-4" />, label: 'Messages' },
            { icon: <FileText className="w-4 h-4" />, label: 'Reports' },
            { icon: <Settings className="w-4 h-4" />, label: 'Settings' },
          ].map((item) => (
            <button
              key={item.label}
              className={`flex items-center gap-3 w-full p-2 rounded-lg text-left ${
                activeSection === item.label.toLowerCase()
                  ? 'bg-blue-50 text-blue-600'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
              onClick={() => setActiveSection(item.label.toLowerCase())}
            >
              {item.icon}
              <span>{item.label}</span>
            </button>
          ))}
        </nav>
      </div>

      <div className="flex-1 p-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold">Dashboard</h1>
        </div>
      </div>
    </div>
  );
};

export default DashboardLayout;
